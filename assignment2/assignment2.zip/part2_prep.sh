rm -rf q2_p2
mkdir -p q2_p2/location1/meddle
mkdir -p q2_p2/location1
echo "TestString " > q2_p2/location1/meat.txt
echo "TestString " > q2_p2/location1/ommeui.txt
echo "TestString " > q2_p2/location1/ommeuf.txt
echo "TestString " > q2_p2/location1/oooome.txt
echo "TestString " > q2_p2/location1/oooo.me
echo "TestString " > q2_p2/location1/oooo.mi
chmod o+w q2_p2/location1/oooo.mi
mkdir -p q2_p2/location1/zebra
echo "TestString " > q2_p2/location1/zebra/zero.tmef
echo "TestString " > q2_p2/location1/zebra/zero
echo "TestString " > q2_p2/location1/zebra/zero.txt
mkdir -p q2_p2/location1/zany
echo "TestString" > q2_p2/location1/zany/topaz.txt
mkdir -p q2_p2/location2/orchard
echo "TestString" > q2_p2/location2/orchard/nomad.txt
mkdir -p q2_p2/location2/orchard/zello
echo "TestString" > q2_p2/location2/orchard/zello/noether.ditto
chmod o+w q2_p2/location2/orchard/zello/noether.ditto
