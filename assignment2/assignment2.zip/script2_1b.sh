chmod -R u=rwx question1
rm -rf question1