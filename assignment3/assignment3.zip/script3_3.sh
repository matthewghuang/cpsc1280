set -f -u

echo "$1" is a member of twoset '$(violin)', he has perfect pitch. "$1" has been playing the \'violin\' for 10* years[ref 123], and he\'s known to have \"Perfect Pitch\",{ref 345}. "$1" has played in Australian Orechestra*.